import numpy as np
from skimage import io
import SimpleITK as sitk
from medpy.io import load
import scipy.io as sio
from glob import glob
import os
import copy as cp
from numpy.lib import stride_tricks


if __name__ == '__main__':

	mainPath = '/home/by354/mywork/datasets/dose_originaldata_yan/PE*'
	savePath = '/home/by354/mywork/testcode/GANs/3D-pytorch-CycleGAN-and-pix2pix/datasets/dose-3D-007-resize/'
	labelPath = glob(mainPath)



	for eachPath in labelPath:


		fn = os.path.basename(eachPath)
		print(fn)

		im1n,h = load( eachPath+'/'+fn+'-pet-180-1-align-resample.img')
		im1n = np.array(im1n)
		im1n = np.moveaxis(im1n,[0,1,2],[-2,-1,-3])
		im2n,h = load( eachPath+'/'+fn+'-pet-720-align-resample.img')
		im2n = np.array(im2n)
		im2n = np.moveaxis(im2n,[0,1,2],[-2,-1,-3])


		t1,h = load( eachPath+'/'+fn+'-t1-reorient-alignToPet-strip-align-resample.img')
		t1 = np.array(t1)
		t1 = np.moveaxis(t1,[0,1,2],[-2,-1,-3])

		mask = np.zeros((128,128,128))

		posi1=np.argwhere(t1<>0)
		for po in posi1:
			mask[po[0],po[1],po[2]]=1


		data = cp.copy(im1n)*mask
		amin1_m = np.amin(data[np.nonzero(data)])
		amax1_m = np.amax(data[np.nonzero(data)])
		im1n = cp.copy(((im1n-amin1_m)/(amax1_m-amin1_m)* mask)-0.5)*2

		data = cp.copy(im2n)*mask
		amin2_m = np.amin(data[np.nonzero(data)])
		amax2_m = np.amax(data[np.nonzero(data)])
		im2n = cp.copy(((im2n-amin2_m)/(amax2_m-amin2_m)* mask)-0.5)*2



		for k in xrange(5):
			for i in xrange(5):
				for j in xrange(5):


					eachMask = cp.copy(mask[(k*16):(k*16+64),(i*16):(i*16+64),(j*16):(j*16+64)])
					posi = np.argwhere(eachMask==1)

					if len(posi)==0:
						continue

					eachPatch1n = cp.copy(im1n[(k*16):(k*16+64),(i*16):(i*16+64),(j*16):(j*16+64)])
					eachPatch2n = cp.copy(im2n[(k*16):(k*16+64),(i*16):(i*16+64),(j*16):(j*16+64)])

					newImgA = eachPatch1n

					newImgB = eachPatch2n


					newImgAB = np.concatenate([newImgA, newImgB],axis=0)

					savImg = sitk.GetImageFromArray(newImgAB)

					if fn=='hp007':
						sitk.WriteImage(savImg,savePath+'test/'+fn+'_'+str(i)+'_'+str(j)+'_'+str(k)+'.nii')
					else:
						sitk.WriteImage(savImg,savePath+'train/'+fn+'_'+str(i)+'_'+str(j)+'_'+str(k)+'.nii')


		


		
