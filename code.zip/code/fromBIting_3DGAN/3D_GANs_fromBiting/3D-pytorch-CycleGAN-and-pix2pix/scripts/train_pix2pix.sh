
python train.py --dataroot ./datasets/dose-3D-007 --name dose-3D-007 --model pix2pix --which_model_netG unet_64 --which_direction AtoB --lambda_A 300 --dataset_mode aligned --no_lsgan --use_dropout


