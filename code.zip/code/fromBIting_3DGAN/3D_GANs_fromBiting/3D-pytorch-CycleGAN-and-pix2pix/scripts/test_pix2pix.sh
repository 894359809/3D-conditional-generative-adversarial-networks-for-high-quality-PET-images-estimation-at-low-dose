
python test.py --dataroot ./datasets/dose-3D-007 --name dose-3D-007 --model pix2pix --which_model_netG unet_64 --which_direction AtoB --dataset_mode aligned --use_dropout


