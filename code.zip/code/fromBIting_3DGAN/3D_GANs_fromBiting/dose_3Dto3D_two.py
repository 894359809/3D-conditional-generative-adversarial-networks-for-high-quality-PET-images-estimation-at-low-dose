import numpy as np
from skimage import io
import SimpleITK as sitk
from medpy.io import load
import scipy.io as sio
from glob import glob
import os
import copy as cp
from numpy.lib import stride_tricks


if __name__ == '__main__':

	mainPath = '/home/by354/mywork/datasets/dose_originaldata_yan/hp*'
	savePath = '/home/by354/mywork/testcode/GANs/3D-pytorch-CycleGAN-and-pix2pix/results/dose-3D-007-16samples-200lambda/test_latest/images/'
	labelPath = glob(mainPath)

	temp = 0 

	for eachPath in labelPath:


 
		fn = os.path.basename(eachPath)
		print(fn)
		if fn<>'hp007':
			continue 
 



		t1,h = load( eachPath+'/'+fn+'-t1-reorient-alignToPet-strip-align-resample.img')
		t1 = np.array(t1)
		t1 = np.moveaxis(t1,[0,1,2],[-2,-1,-3])

		mask = np.zeros((128,128,128))
		padPatch = np.zeros((128,128,128))
		sub = np.ones((64,64,64))
		padSub = np.zeros((128,128,128))

		posi1=np.argwhere(t1<>0)
		for po in posi1:
			mask[po[0],po[1],po[2]]=1





		
		for k in xrange(5):
			for i in xrange(5):
				for j in xrange(5):

					eachSub = np.zeros((128,128,128))
					eachSub[(k*16):(k*16+64),(i*16):(i*16+64),(j*16):(j*16+64)] = sub
					padSub = padSub + cp.copy(eachSub)

					eachMask = cp.copy(mask[(k*16):(k*16+64),(i*16):(i*16+64),(j*16):(j*16+64)])
					posi = np.argwhere(eachMask==1)

					if len(posi)==0:
						continue

					eachPadPatch = np.zeros((128,128,128))

					eachPatch = io.imread( savePath+fn+'_'+str(i)+'_'+str(j)+'_'+str(k)+'_fake_B.nii', plugin = 'simpleitk')
					eachPatch = np.array(eachPatch).reshape((64,64,64))
					eachPadPatch[(k*16):(k*16+64),(i*16):(i*16+64),(j*16):(j*16+64)] = cp.copy(eachPatch)
					padPatch = padPatch + cp.copy(eachPadPatch)




		new1n = cp.copy(padPatch)/cp.copy(padSub)

		new1n = (new1n+1)/2*mask

		new1n[np.where(padSub==0)] = 0

		
		new1n = np.moveaxis(new1n,[0,1,2],[0,2,1])
		savImg1 = sitk.GetImageFromArray(new1n)
		sitk.WriteImage(savImg1, eachPath +'/' + fn +'-pet-720-fake-3D-16samples-200lambda.img')
