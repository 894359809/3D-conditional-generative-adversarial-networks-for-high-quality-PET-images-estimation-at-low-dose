

python train.py --dataroot ./datasets/dose-2D-007 --name dose-2D-007 --model pix2pix --which_model_netG unet_128 --which_direction AtoB --lambda_A 100 --dataset_mode aligned --no_lsgan --use_dropout
